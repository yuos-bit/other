> [!IMPORTANT]
> The Tailscale API documentation has moved to https://tailscale.com/api
